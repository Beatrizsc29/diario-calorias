# Diário de Calorias — Como colocar no seu celular (100% grátis)

Este app é um PWA (Progressive Web App): um site que se instala como aplicativo,
com ícone na tela inicial, tela cheia e dados salvos no próprio celular.
Não depende do Claude para funcionar.

## Passo 1 — Criar sua chave gratuita da Groq (IA que analisa as fotos)

1. Acesse https://console.groq.com e crie uma conta (grátis, sem cartão)
2. Vá em **API Keys** → **Create API Key**
3. Copie a chave (começa com `gsk_...`) — você vai colar no app na primeira vez que abrir

O plano gratuito da Groq é generoso: dá para dezenas de análises por dia sem pagar nada.

## Passo 2 — Publicar o app no GitHub Pages (grátis)

Você já tem conta no GitHub (Rodovalho071), então:

1. Crie um repositório novo, ex: `diario-calorias` (pode ser público)
2. Envie estes 5 arquivos para o repositório:
   - index.html
   - manifest.json
   - sw.js
   - icon-192.png
   - icon-512.png
3. No repositório: **Settings → Pages → Branch: main → / (root) → Save**
4. Em 1-2 minutos o app estará no ar em:
   `https://rodovalho071.github.io/diario-calorias/`

(Alternativa: o Render também hospeda "Static Site" grátis, igual você já usa.)

## Passo 3 — Instalar no celular

1. Abra o link acima no navegador do celular (Chrome ou Safari)
2. Na primeira vez, cole sua chave da Groq quando o app pedir
3. **Android (Chrome):** menu ⋮ → "Adicionar à tela inicial" → "Instalar"
   **iPhone (Safari):** botão compartilhar → "Adicionar à Tela de Início"
4. Pronto! O app abre em tela cheia, com ícone próprio, como qualquer aplicativo.

## Observações

- Os registros ficam salvos **no próprio celular** (localStorage). Se limpar os
  dados do navegador, o histórico é apagado.
- A chave da Groq também fica salva só no seu celular — não vai para o repositório.
- Nunca coloque a chave dentro do index.html se o repositório for público.
- A análise por foto precisa de internet; o restante do app funciona offline.
